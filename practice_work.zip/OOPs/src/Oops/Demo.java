package Oops;

public class Demo {

	public static void main(String[] args) {
		
		int a=80;
		int b=14;
		
//		Demo demo = new Demo();
                 Sum sum = new Sum();
                 int result=sum.addNumber(a, b);
                 System.out.println(result);
//		int data=demo.addNumber(a,b);
//		System.out.println(data);
		
	}
	
}


class Sum{
	
	public int addNumber(int first, int second) {
		
		return first+second;
		
	}

}

