package Oops;

public class ClassB extends ClassA {
	
	int meth1() {
		System.out.println("ClassB meth2() called");
		return 65;
	}

	public static void main(String[] args) {
	
	ClassA aobj1=new ClassA();
	int b=aobj1.meth1(100);
	System.out.println(b );
//	aobj1.meth2();
	System.out.println("======================================");
	
	ClassA aobj2=new ClassB();
	aobj2.meth1(500);
//	aobj2.meth2();
	System.out.println("=======================================");
	
	ClassB bobj=new ClassB();
	int a=bobj.meth1(200);
	System.out.println(a);
	bobj.meth1();
	System.out.println();
	System.out.println("===========================================");
	
	
	}
}
