package Oops;

public class ClassA {

	int meth1(int x){
		System.out.println("ClassA meth1() Called");
		return 'A'-60;
	}
		
		
}
