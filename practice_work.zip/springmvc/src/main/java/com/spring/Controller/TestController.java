 package com.spring.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@RequestMapping("/msg")
	public String getMsg() {
		return "HELLO..... GAURAV MASKE";
	}
	
//	@RequestMapping("/welcome")
//	public String getWelcome() {
//		return "WE ARE WELCOME YOU !!!";
//	}
}
  