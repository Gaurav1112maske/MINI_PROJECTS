package com.spring.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/user")
public class UserController {

//	@ResponseBody
	@RequestMapping(path = "/login")
	public String welcomeMsg(Model model) {
		model.addAttribute("name","GAURAV MASKE");
		model.addAttribute("mail", "gauravmaske1@gmail.com");
		return "welcome";
	}
	
	 
	@PostMapping("/register")
	@ResponseBody
	public String getRegister(Model model , HttpServletRequest Request) {
		
		String username = Request.getParameter("name");
	String password = Request.getParameter("mail");
	
	
		
		return "USER RESITRATION DONE BY  "+username+"  AND PASSWORD IS  "+password;
	}
}
