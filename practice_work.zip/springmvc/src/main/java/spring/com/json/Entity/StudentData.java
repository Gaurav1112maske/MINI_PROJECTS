package spring.com.json.Entity;

public class StudentData {

	private String studentName;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public StudentData(String studentName) {
		super();
		this.studentName = studentName;
	}

	public StudentData() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

}
