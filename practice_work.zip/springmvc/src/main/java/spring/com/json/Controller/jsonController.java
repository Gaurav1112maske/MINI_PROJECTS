package spring.com.json.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import spring.com.json.Entity.StudentData;

@RestController
@RequestMapping("/user")
public class jsonController {

	@PostMapping("/data")
	public String getStudentData(@RequestBody StudentData student) {
		
		
		System.out.println(student.getStudentName());
				
		return "DATA SUCESSFULLY RETRIVED";
		
	}
}
