package com.spring.JpaRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.Entity.EmpEntity;

public interface EmpRepository extends JpaRepository<EmpEntity, String> {

}
