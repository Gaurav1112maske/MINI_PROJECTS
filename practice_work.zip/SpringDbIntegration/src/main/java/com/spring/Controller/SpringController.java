package com.spring.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Register.UserRegisterRequest;
import com.spring.Response.UserRegistrationResponse;
import com.spring.Service.UserService;

@RestController
@RequestMapping("/spring")
public class SpringController {

	@Autowired
	UserService userService;

	@PostMapping("/create")
	public String registerUserDetails(@RequestBody UserRegisterRequest request) {
		// Controller -> Service and From Service receiving Result
		String response = userService.registerUserDetails(request);
		return response;
	}
		
		
		
	}
