package com.spring.Register;

public class UserRegisterRequest {

	private String userName;
	private String userEmail;
	private String userNumber;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(String userNumber) {
		this.userNumber = userNumber;
	}
	public UserRegisterRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserRegisterRequest(String userName, String userEmail, String userNumber) {
		super();
		this.userName = userName;
		this.userEmail = userEmail;
		this.userNumber = userNumber;
	}
	
	
	
}
