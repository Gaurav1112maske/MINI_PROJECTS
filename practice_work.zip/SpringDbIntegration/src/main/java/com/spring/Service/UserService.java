 package com.spring.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.Entity.EmpEntity;
import com.spring.JpaRepository.EmpRepository;
import com.spring.Register.UserRegisterRequest;

@Service
public class UserService {

	@Autowired
	EmpRepository repo;
	public String registerUserDetails(UserRegisterRequest registerRequest) {
		// Mapping data to Entity Object
		EmpEntity user = new EmpEntity();
		user.setUserName(registerRequest.getUserName());
		user.setUserEmail(registerRequest.getUserEmail());
		user.setUserNumber(registerRequest.getUserNumber());
		return "User Registered Successfully";	
	}
	
}
