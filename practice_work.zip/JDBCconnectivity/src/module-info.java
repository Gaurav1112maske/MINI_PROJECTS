/**
 * 
 */
/**
 * @author DELL
 *
 */
module JDBCconnectivity {
	requires java.sql;
}