package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dynamicquery {

	public static void main(String[] args) {
		
	
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
				System.out.println("CONNECTION ESTABLISHED SUCCESSFULLY");
				
//				PreparedStatement pstmt=con.prepareStatement("insert into student0101 values(?,?)");
//				pstmt.setInt(1, Integer.parseInt(args[0]));
//				pstmt.setString(2,args[1]);
//				
//				pstmt.executeUpdate();
//				System.out.println("DATA INSERTED SUCCESSFULLY");
//				
//				System.out.println("==================================================================");
//				
//				PreparedStatement pstmt=con.prepareStatement("select * from student0101 where rollno=?");
//				pstmt.setInt(1,Integer.parseInt(args[0]));
////				pstmt.setString(2,args[1]);
//				
//				ResultSet rs=pstmt.executeQuery();
//				while(rs.next()) {
//					System.out.print(rs.getInt(1)+"  " );
//					System.out.println(rs.getString(2));
//				}
////			pstmt.executeUpdate();
//				System.out.println("RETRIVING DATA DYNAMICALY");
//				System.out.println("===================================================================");
//			
				CallableStatement cstmt=con.prepareCall("{call stddata(?,?)}");
				cstmt.setInt(1,107);
				cstmt.setString(2,"godtech");
				cstmt.execute();
				con.close();
				System.out.println("RECORD INSERTED SUCCESSFULLY");
				System.out.println("=====================================================================");
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
