package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class rowset_scrollable_updatable {

	public static void main(String[] args) {
		
	
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
				System.out.println("CONNECTION ESTABLISHED SUCCESSFULLY");
				
				 Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
				 ResultSet rs=stmt.executeQuery("select rollno,name from student0101");
				
//				 rs.absolute(4); //IT WILL SHIFT CURSOR TO THE 4TH ROW
//				 System.out.println(rs.getInt(1));
//				 System.out.println(rs.getString(2)); 
//				 System.out.println("DATA FETCHOUT SUCCESSFULLY");
//				System.out.println("====================================================================");
				 
//				 rs.absolute(3);
//				 rs.updateInt(1, 109);
//				 rs.updateString(2," JAMES");
//				 rs.updateRow();
//				System.out.println("DATA UPDATE SUCCESSFULLY");
//				System.out.println("====================================================================");
				 
//				 rs.moveToInsertRow(); //IT WILL ADD WHERE SPACE AVAILABLE
//				 rs.updateInt(1,110);
//				 rs.updateString(2, "daniel");
//				 rs.insertRow();
//				 System.out.println("ONE ROW INSERTED SUCCESSFULLY");
				 
				 
//				 rs.absolute(3);
//				 rs.deleteRow();
//				 System.out.println("ONE RECORD DELETED SUCCESSFULLY ");
				
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	}

}
