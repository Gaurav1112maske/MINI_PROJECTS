package jdbc;

import java.sql.Connection;
import java.sql.*;

public class ClassA 
{
	public static void main(String args[])
	{
		try
		{
			Class C =Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");	
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from student1");
		
	System.out.println("data inserted successfully");
	//System.out.println(rs);
	ResultSetMetaData rsmd =rs.getMetaData();
	int n= rsmd.getColumnCount();
	
	ResultSetMetaData rsmd1 =rs.getMetaData();
	int n1= rsmd.getColumnCount();
	for(int i=1;i<=n1;i++)
	{
		System.out.print(rsmd1.getColumnName(i)+" ");	
	}
	System.out.println();
	
	while(rs.next())
	{
		for(int i=1;i<=n1;i++)
		{
			System.out.print(rs.getString(i)+ " ");
		}
		System.out.println();
	}
		}
		catch(Exception e)
		{
			System.err.println(e);
		}
	}
}
