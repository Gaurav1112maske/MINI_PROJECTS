package jdbc;
import java.sql.*;
public class ClassC 
{
	public static void main(String[] args) 
	{
		try
		{
			Class C = Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
		
		PreparedStatement pstmt = con.prepareStatement("select rollno,sname from student1 where smarks=?");
		pstmt.setInt(3, Integer.parseInt(args[0]));
		ResultSet rs=pstmt.executeQuery();
		System.out.println("Data retrived successfully");
		if(rs.next())
		{
			System.out.print(rs.getInt(0)+ " ");
			System.out.print(rs.getString(1)+ " ");
			//System.out.print(rs.getInt(2));
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}

}

