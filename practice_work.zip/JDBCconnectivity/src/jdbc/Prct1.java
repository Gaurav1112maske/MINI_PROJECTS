package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Prct1
{
	public static void main(String[] args)
	{
		try
		{
		Class C = Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
		Statement stmt=con.createStatement();		
		stmt.execute("create table test1(sid number(10),snmae varchar2(10),smarks number(10))");
				System.out.println("table created successfully");
				
		stmt.executeUpdate("insert into test1 values(101,'GAURAV',75)");
		System.out.println("data entered successfully");
				
				
		}
		catch (ClassNotFoundException|SQLException e)
		{
			System.out.println(e);
		}
		}

}
