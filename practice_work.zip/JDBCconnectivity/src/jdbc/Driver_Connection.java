 package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Driver_Connection 
{
	public static void main(String[] args)
	{
				try
				{
				
					Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection			
						("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
				System.out.println("Connection created successfully");	
				Statement stmt=con.createStatement();
				stmt.execute("create table myclassdata(rollno number(10), name varchar2(10), marks number(10))");
				System.out.println("table created ");
				stmt.executeUpdate("insert into myclassdata values(101,'GAURAV',75)");
				stmt.executeUpdate("insert into myclassdata values(102,'snehal',96)");
				System.out.println("data enterd successfullly");
				}
			catch(Exception e)
			{
				System.err.println(e);
			}
				finally {
					System.out.println();
				}
			}
		
}
