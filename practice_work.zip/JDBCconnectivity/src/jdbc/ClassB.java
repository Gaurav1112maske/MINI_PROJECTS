package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.*;

public class ClassB 
{
public static void main(String[] args) 
{
	try{
		Class c=Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
		PreparedStatement prst=con.prepareStatement("insert into student1 values(?,?,?)");
		
		
		prst.setInt(1,Integer.parseInt(args[0]));
		prst.setString(2,args[1]);
		prst.setInt(3,Integer.parseInt(args[2]));
		int n=prst.executeUpdate();
		System.out.println("ONE RECORD INSERTED SUCCESSFULLY");
	}
		catch(Exception e)
		{
		   System.err.print(e);
		} 
	}
}

