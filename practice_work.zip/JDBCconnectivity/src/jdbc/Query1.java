package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Query1 {

	public static void main(String[] args) 
	{
		try {
			Class c1=Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Gargi","gargi123");
		    System.out.println("connection established");
			 
		    
		   Statement stmt =con.createStatement();
		   //stmt.execute("create table t20(sid number(10),sname varchar2(10))");
		
		   System.out.println("data insert zala");
		 
		   stmt.executeUpdate("insert into t20 values(10,'sneh')");
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
		

	}

}
