package java_Lamda_Expression;

public class Thread_Using_Lambdda implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("THREAD CREATED SUCCESSFULLY");
	}

	public static void main(String[] args) {
		
		Thread_Using_Lambdda using_Lambdda = new Thread_Using_Lambdda();
		
		Thread thread = new Thread(using_Lambdda);
		
		thread.start();
		
		
		
		Runnable runnable = () -> System.out.println("USING LAMBDAD EXPRESSION");
		
		Thread thread2 = new Thread(runnable);
		
		thread2.start();
	}
}
