package java_Lamda_Expression;

interface InterfaceA {

//	public void meth1();

	public int meth2(int a, int b);
}

public class Lambda_Expression implements InterfaceA {

//	public void meth1() {
//		// TODO Auto-generated method stub
//		
//		System.out.println("THIS IS REGULAR WAY OF WRITING INTERFACE IMPLEMENTATION ");
//	}

	@Override
	public int meth2(int a, int b) {
		// TODO Auto-generated method stub
		return a + b;
	}

	public static void main(String[] args) {

		Lambda_Expression lambda_Expression = new Lambda_Expression();
//		lambda_Expression.meth1();

//		int i = lambda_Expression.meth2(12, 34);
//		System.out.println(i);

//		InterfaceA lambda = () -> System.out.println("INTERFACE IMPLEMENATTAION USING LAMBDA EXPRESSION");
//		lambda.meth1();

		InterfaceA lambdad1 = (int x, int y) -> x + y;
		int meth2 = lambdad1.meth2(12, 8);
		System.out.println(meth2);
		System.out.println(lambdad1.meth2(12, 8));
		
		
		
		
		
	}

}
