package java_Lamda_Expression;

class ConsumerImpl implements java.util.function.Consumer<String>{

	@Override
	public void accept(String t) {
		// TODO Auto-generated method stub
		System.out.println(t);
	}
	
}

public class Consumer {

	public static void main(String[] args) {
		
//		Consumer<String> consumerImpl = new ConsumerImpl();
		
//			ConsumerImpl impl = new ConsumerImpl();
//		
//			impl.accept("GAURAV");
			
			
		Consumer consumer = (t) -> System.out.print(t) ;
		consumer.accept("GAYRAV");
			
	}
}
