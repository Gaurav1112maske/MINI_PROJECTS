package java_Lamda_Expression;

import java.util.function.Function;

abstract class FunctionDao implements Function<String, Integer> {

//	@Override
//	public Integer apply(String t) {
//		// TODO Auto-generated method stub
//		return t.length();
//	}
}
public class FunctionalImpl {

	public static void main(String[] args) {

//		Function<String, Integer> functionDao = new FunctionDao();
//		Integer integer = functionDao.apply("GAURAV");
//		System.out.println(integer);

		Function<String, Integer> function1 = (String s) -> s.length();
		
		System.out.println(function1.apply("GAURAV"));
		
	}

}
