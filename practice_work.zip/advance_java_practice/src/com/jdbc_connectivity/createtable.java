package com.jdbc_connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class createtable {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","Cgpm","guru1112");
			System.out.println("CONNECTION ESTABLISHED");
			
			Statement stmt=con.createStatement();
			stmt.execute("create table student0106 (rollno number(3),name varchar2(10))");
			
			stmt.executeUpdate("insert into  student0106 values(101,'GAURAV')");
			stmt.executeUpdate("insert into  student0106 values(102,'SNEHAL')");
			
			ResultSet rs=stmt.executeQuery("select * from student0106");
		ResultSetMetaData rsmd=rs.getMetaData();
		
		int n = rsmd.getColumnCount();
//		System.out.println(n); 
		for(int i=1;i<=n;i++)
		{
				System.out.println(rsmd.getColumnName(i));
		}
		System.out.println();
				
		while(rs.next()) {
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
		}
		
			System.out.println("TABLE IS CREATED SUCCESSFULLY");
			System.out.println("DATA INSERTED IS CREATED SUCCESSFULLY");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
