/**
 * 
 */
/**
 * @author DELL
 *
 */
module advance_java_practice {
	requires java.sql;
	requires ojdbc8.g;
}