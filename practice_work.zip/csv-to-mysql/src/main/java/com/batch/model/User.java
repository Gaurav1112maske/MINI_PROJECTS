package com.batch.model;

public class User {

	private String sector;
	private String topic;
	private String url;
	private String source;
	
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public User(String sector, String url, String topic, String source) {
		super();
		this.sector = sector;
		this.url = url;
		this.topic = topic;
		this.source = source;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [sector=" + sector + ", url=" + url + ", topic=" + topic + ", source=" + source + "]";
	}
	
	

}
