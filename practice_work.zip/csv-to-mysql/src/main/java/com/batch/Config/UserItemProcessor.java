package com.batch.Config;

import org.springframework.batch.item.ItemProcessor;

import com.batch.model.User;

public class UserItemProcessor implements ItemProcessor<User, User>{

	@Override
	public User process(User item) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
 