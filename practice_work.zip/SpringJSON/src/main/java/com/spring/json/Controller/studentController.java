package com.spring.json.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.json.StudentData.Student;

@RestController
@RequestMapping("/student")
public class studentController {

	@PostMapping("/data")
	public String getStudentData(@RequestBody Student student) {
		
		System.out.println(student.getStudentName());
		return "DATA GOT SUCESSFULLY";
	}
}
